var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./PCFComentarioPortal/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./PCFComentarioPortal/index.ts":
/*!**************************************!*\
  !*** ./PCFComentarioPortal/index.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nvar __awaiter = this && this.__awaiter || function (thisArg, _arguments, P, generator) {\n  function adopt(value) {\n    return value instanceof P ? value : new P(function (resolve) {\n      resolve(value);\n    });\n  }\n\n  return new (P || (P = Promise))(function (resolve, reject) {\n    function fulfilled(value) {\n      try {\n        step(generator.next(value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n\n    function rejected(value) {\n      try {\n        step(generator[\"throw\"](value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n\n    function step(result) {\n      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);\n    }\n\n    step((generator = generator.apply(thisArg, _arguments || [])).next());\n  });\n};\n\nvar __generator = this && this.__generator || function (thisArg, body) {\n  var _ = {\n    label: 0,\n    sent: function sent() {\n      if (t[0] & 1) throw t[1];\n      return t[1];\n    },\n    trys: [],\n    ops: []\n  },\n      f,\n      y,\n      t,\n      g;\n  return g = {\n    next: verb(0),\n    \"throw\": verb(1),\n    \"return\": verb(2)\n  }, typeof Symbol === \"function\" && (g[Symbol.iterator] = function () {\n    return this;\n  }), g;\n\n  function verb(n) {\n    return function (v) {\n      return step([n, v]);\n    };\n  }\n\n  function step(op) {\n    if (f) throw new TypeError(\"Generator is already executing.\");\n\n    while (_) try {\n      if (f = 1, y && (t = op[0] & 2 ? y[\"return\"] : op[0] ? y[\"throw\"] || ((t = y[\"return\"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;\n      if (y = 0, t) op = [op[0] & 2, t.value];\n\n      switch (op[0]) {\n        case 0:\n        case 1:\n          t = op;\n          break;\n\n        case 4:\n          _.label++;\n          return {\n            value: op[1],\n            done: false\n          };\n\n        case 5:\n          _.label++;\n          y = op[1];\n          op = [0];\n          continue;\n\n        case 7:\n          op = _.ops.pop();\n\n          _.trys.pop();\n\n          continue;\n\n        default:\n          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {\n            _ = 0;\n            continue;\n          }\n\n          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {\n            _.label = op[1];\n            break;\n          }\n\n          if (op[0] === 6 && _.label < t[1]) {\n            _.label = t[1];\n            t = op;\n            break;\n          }\n\n          if (t && _.label < t[2]) {\n            _.label = t[2];\n\n            _.ops.push(op);\n\n            break;\n          }\n\n          if (t[2]) _.ops.pop();\n\n          _.trys.pop();\n\n          continue;\n      }\n\n      op = body.call(thisArg, _);\n    } catch (e) {\n      op = [6, e];\n      y = 0;\n    } finally {\n      f = t = 0;\n    }\n\n    if (op[0] & 5) throw op[1];\n    return {\n      value: op[0] ? op[1] : void 0,\n      done: true\n    };\n  }\n};\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar PCFComentarioPortal =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function PCFComentarioPortal() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  PCFComentarioPortal.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    this.webApiContext = context.webAPI;\n    this.localContext = context;\n    this.localContainer = container;\n    this.localContainer.style.maxHeight = \"400px\";\n    this.localContainer.style.minHeight = \"200px\";\n    this.localContainer.style.textAlign = \"center\";\n    this.divelementForm = document.createElement(\"div\");\n    this.setTextPorIdioma();\n    this.criaDivAlerta();\n    this.createForm(this.divelementForm);\n    this.localContainer.appendChild(this.divalertaMensagem);\n    this.localContainer.appendChild(this.divelementForm);\n    this.entityId = context.page.entityId;\n    console.log(Xrm.Page.getControl(\"primarycontactid\").getAttribute().getValue());\n  };\n\n  PCFComentarioPortal.prototype.setTextPorIdioma = function () {\n    var idioma = Xrm.Page.context.getUserLcid();\n\n    switch (idioma) {\n      case 1046:\n        this.saveButtonInnerText = \"Enviar\";\n        this.clearButtonInnerText = \"Limpar\";\n        this.textAreaInnerText = \"Digite o texto\";\n        this.SucessoInnerText = \"Sucesso\";\n        this.ErrorInnerText = \"Erro ao criar comentário, notifique o administradoe\";\n        break;\n\n      case 3082:\n        this.saveButtonInnerText = \"Enviar\";\n        this.clearButtonInnerText = \"Limpar\";\n        this.textAreaInnerText = \"Insertar texto\";\n        this.SucessoInnerText = \"Sucesso\";\n        this.ErrorInnerText = \"Error al crear el comentario, notifique al administrador\";\n        break;\n\n      default:\n        this.saveButtonInnerText = \"Submit\";\n        this.clearButtonInnerText = \"Cancel\";\n        this.textAreaInnerText = \"Enter text\";\n        this.SucessoInnerText = \"success\";\n        this.ErrorInnerText = \"Error creating comment, please notify the Administrator\";\n        break;\n    }\n  };\n\n  PCFComentarioPortal.prototype.createForm = function (_divElementForm) {\n    var divTextArea = this.createDiv(\"itsm_item itsm_width_100\");\n    var textArea = document.createElement(\"textarea\");\n    textArea.className = \"itsm_textarea \";\n    textArea.placeholder = this.textAreaInnerText;\n    textArea.maxLength = 100000;\n    divTextArea.append(textArea);\n    var divInput = this.createDiv(\"itsm_item\");\n    var input = document.createElement(\"input\");\n    input.type = \"file\";\n    input.title = \"arquivo\";\n    input.className = \"itsm_input\";\n    input.style.opacity = \"100\";\n    input.style.position = \"relative\";\n    input.style.pointerEvents = \"all\";\n    input.style.cursor = \"pointer\";\n    input.style.width = \"100%\";\n    input.style.height = \"30%\";\n    divInput.append(input);\n    var divButtons = this.createDiv(\"itsm_item\");\n    var buttonSave = this.createButton(\"itsm_button_comment itsm_save\");\n    buttonSave.innerHTML = \"<p> \" + this.saveButtonInnerText + \" </p>\";\n    buttonSave.title = this.saveButtonInnerText;\n    var buttonCancel = this.createButton(\"itsm_button_comment itsm_cancel\");\n    buttonCancel.innerHTML = \"<p> \" + this.clearButtonInnerText + \" </p>\";\n    buttonCancel.title = this.clearButtonInnerText;\n    buttonSave.addEventListener(\"click\", this.chamaCriacaoRegistros.bind(this, buttonSave, textArea, input));\n    buttonCancel.addEventListener(\"click\", this.limpaCampos.bind(this, textArea, input));\n    divButtons.append(buttonSave);\n    divButtons.appendChild(buttonCancel);\n\n    _divElementForm.append(divTextArea);\n\n    _divElementForm.appendChild(divInput);\n\n    _divElementForm.appendChild(divButtons);\n  };\n\n  PCFComentarioPortal.prototype.createDiv = function (classe) {\n    var div;\n    div = document.createElement(\"div\");\n    div.className = classe;\n    return div;\n  };\n\n  PCFComentarioPortal.prototype.createButton = function (classe) {\n    var button;\n    button = document.createElement(\"button\");\n    button.className = classe;\n    return button;\n  };\n\n  PCFComentarioPortal.prototype.chamaCriacaoRegistros = function (botao, textArea, inputFiles) {\n    var _a, _b;\n\n    return __awaiter(this, void 0, void 0, function () {\n      var descricao, idComentario, IdAnotacao, index, base;\n      return __generator(this, function (_c) {\n        switch (_c.label) {\n          case 0:\n            this.desabilitaHabilitaBotao(botao, true);\n            descricao = textArea.value;\n            IdAnotacao = \"\";\n            if (!(descricao != null && descricao.replace(\" \", \"\").length > 0)) return [3\n            /*break*/\n            , 9];\n            return [4\n            /*yield*/\n            , this.criaComentario(descricao)];\n\n          case 1:\n            idComentario = _c.sent();\n            if (!(idComentario != \"\")) return [3\n            /*break*/\n            , 7];\n            if (!(inputFiles != null && ((_a = inputFiles.files) === null || _a === void 0 ? void 0 : _a.length))) return [3\n            /*break*/\n            , 6];\n            index = 0;\n            _c.label = 2;\n\n          case 2:\n            if (!(index < ((_b = inputFiles.files) === null || _b === void 0 ? void 0 : _b.length))) return [3\n            /*break*/\n            , 6];\n            return [4\n            /*yield*/\n            , this.getBase64(inputFiles.files[index])];\n\n          case 3:\n            base = _c.sent();\n            return [4\n            /*yield*/\n            , this.createAnotacao(idComentario, \"adx_portalcomment\", base, inputFiles.files[index])];\n\n          case 4:\n            IdAnotacao = _c.sent();\n            _c.label = 5;\n\n          case 5:\n            index++;\n            return [3\n            /*break*/\n            , 2];\n\n          case 6:\n            this.mostraMensagenAlerta(this.SucessoInnerText, \"rgb(0, 255, 0,0.2)\");\n            this.desabilitaHabilitaBotao(botao, false);\n            this.limpaCampos(textArea, inputFiles);\n            return [3\n            /*break*/\n            , 8];\n\n          case 7:\n            this.mostraMensagenAlerta(this.ErrorInnerText, \"rgb(255, 0, 0,0.2)\");\n            this.desabilitaHabilitaBotao(botao, false);\n            _c.label = 8;\n\n          case 8:\n            return [3\n            /*break*/\n            , 10];\n\n          case 9:\n            this.mostraMensagenAlerta(\"O campo de descrição é obrigatório\", \"rgb(255, 0, 0,0.2)\");\n            this.desabilitaHabilitaBotao(botao, false);\n            _c.label = 10;\n\n          case 10:\n            return [2\n            /*return*/\n            ];\n        }\n      });\n    });\n  };\n\n  PCFComentarioPortal.prototype.desabilitaHabilitaBotao = function (botao, bool) {\n    botao.disabled = bool;\n  };\n\n  PCFComentarioPortal.prototype.mostraMensagenAlerta = function (mensgem, background) {\n    var _this = this;\n\n    this.divalertaMensagem.style.display = \"block\";\n    this.divalertaMensagem.style.backgroundColor = background;\n    this.divalertaMensagem.innerText = mensgem;\n    setTimeout(function () {\n      _this.divalertaMensagem.style.display = \"none\";\n    }, 2000);\n  };\n\n  PCFComentarioPortal.prototype.criaDivAlerta = function () {\n    var divAlerta = this.createDiv(\"itsm_alerta\");\n\n    var _pMensagem = document.createElement(\"p\");\n\n    _pMensagem.className = \"itsm_message_alert\";\n    this.pMensagem = _pMensagem; //divAlerta.append(this.pMensagem);\n\n    this.divalertaMensagem = divAlerta;\n  };\n\n  PCFComentarioPortal.prototype.limpaCampos = function (textArea, inputElement) {\n    var _a;\n\n    textArea.value = \"\";\n\n    if (inputElement != null && inputElement.files != undefined && ((_a = inputElement.files) === null || _a === void 0 ? void 0 : _a.length) > 0) {\n      inputElement.value = \"\";\n    }\n  };\n\n  PCFComentarioPortal.prototype.criaComentario = function (descricao) {\n    return __awaiter(this, void 0, void 0, function () {\n      var idContact, idSystemUser, entity, newEntityId;\n\n      var _a;\n\n      return __generator(this, function (_b) {\n        switch (_b.label) {\n          case 0:\n            idContact = Xrm.Page.getAttribute(\"primarycontactid\").getValue()[0].id;\n            idSystemUser = Xrm.Page.context.getUserId();\n            entity = (_a = {\n              \"description\": descricao\n            }, _a[\"regardingobjectid_incident@odata.bind\"] = \"/incidents(\" + this.entityId.replace(\"{\", \"\").replace(\"}\", \"\") + \")\", _a[\"adx_portalcommentdirectioncode\"] = 2, _a[\"statuscode\"] = 1, _a[\"adx_portalcomment_activity_parties\"] = [{\n              \"partyid_systemuser@odata.bind\": \"/systemusers(\" + idSystemUser.replace(\"{\", \"\").replace(\"}\", \"\") + \")\",\n              \"participationtypemask\": 1 ///From Email\n\n            }, {\n              \"partyid_contact@odata.bind\": \"/contacts(\" + idContact.replace(\"{\", \"\").replace(\"}\", \"\") + \")\",\n              \"participationtypemask\": 2 ///To Email\n\n            }], _a);\n            console.log(entity);\n            newEntityId = \"\";\n            return [4\n            /*yield*/\n            , this.webApiContext.createRecord(\"adx_portalcomment\", entity).then(function success(result) {\n              newEntityId = \"\" + result.id;\n            }, function (error) {\n              console.log(error.message);\n            })];\n\n          case 1:\n            _b.sent();\n\n            return [2\n            /*return*/\n            , newEntityId];\n        }\n      });\n    });\n  };\n\n  PCFComentarioPortal.prototype.createAnotacao = function (Id, entityLogicalName, base, file) {\n    return __awaiter(this, void 0, void 0, function () {\n      var criado, attachment;\n\n      var _a;\n\n      return __generator(this, function (_b) {\n        switch (_b.label) {\n          case 0:\n            criado = \"\";\n            console.log(\"mimetype:\");\n            console.log(file);\n            attachment = (_a = {\n              \"subject\": \"Anexo: \" + file.name,\n              \"filename\": file.name,\n              \"filesize\": file.size,\n              \"mimetype\": file.type,\n              \"objecttypecode\": entityLogicalName,\n              \"documentbody\": base\n            }, _a[\"objectid_\" + entityLogicalName + \"@odata.bind\"] = \"/\" + entityLogicalName + \"s(\" + Id + \")\", _a);\n            console.log(attachment);\n            return [4\n            /*yield*/\n            , this.webApiContext.createRecord(\"annotation\", attachment).then(function success(result) {\n              criado = \"\" + result.id;\n              console.log(\"Arquivo criado\");\n              return criado;\n            }, function (error) {\n              console.log(error.message);\n              return criado;\n            })];\n\n          case 1:\n            _b.sent();\n\n            return [2\n            /*return*/\n            , criado];\n        }\n      });\n    });\n  };\n\n  PCFComentarioPortal.prototype.getBase64 = function (file) {\n    return new Promise(function (resolve, reject) {\n      var reader = new FileReader();\n\n      reader.onload = function (f) {\n        return resolve(reader.result.split(',')[1]);\n      };\n\n      reader.onerror = function (error) {\n        return reject(error);\n      };\n\n      reader.readAsDataURL(file);\n    });\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  PCFComentarioPortal.prototype.updateView = function (context) {// Add code to update control view\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  PCFComentarioPortal.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  PCFComentarioPortal.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return PCFComentarioPortal;\n}();\n\nexports.PCFComentarioPortal = PCFComentarioPortal;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PCFComentarioPortal/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('PcfComentarioPortal.PCFComentarioPortal', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PCFComentarioPortal);
} else {
	var PcfComentarioPortal = PcfComentarioPortal || {};
	PcfComentarioPortal.PCFComentarioPortal = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PCFComentarioPortal;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}